/**
 * Module des demandes
 */
package ch.vd.demaut.domain.demandes;