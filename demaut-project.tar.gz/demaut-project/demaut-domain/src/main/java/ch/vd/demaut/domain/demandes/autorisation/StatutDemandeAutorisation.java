package ch.vd.demaut.domain.demandes.autorisation;

public enum StatutDemandeAutorisation {

    Brouillon,
    Soumise,
    Refusee,
    Validee,
    Acceptee;

}
