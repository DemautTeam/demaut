/**
 * Module des demandeurs
 */
package ch.vd.demaut.domain.demandeurs;