package ch.vd.demaut.domain.annexes;

public enum FormatFichier {
    PDF;

}
