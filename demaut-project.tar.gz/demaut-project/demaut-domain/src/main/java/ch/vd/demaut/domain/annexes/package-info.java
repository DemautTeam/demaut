/**
 * Module des annexes
 */
package ch.vd.demaut.domain.annexes;