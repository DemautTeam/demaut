package ch.vd.demaut.domain.demandes.autorisation;

import ch.vd.demaut.commons.vo.DateTimeVO;

public class DateSoumissionDemande extends DateTimeVO {

    // ********************************************************* Constructors
    public DateSoumissionDemande(int annee, int mois, int jourDuMois, int heure, int minute, int seconde) {
        super(annee, mois, jourDuMois, heure, minute, seconde);
    }

    // ********************************************************* Business methods


}
