package ch.vd.demaut.domain.demandes.autorisation;

public enum ProfessionDeLaSante {
    Chiropraticien,
    Dieteticien,
    Droguiste,
    Ergotherapeute,
    HygienisteDentaire,
    Infirmier,
    LogopedisteOrthophoniste,
    MasseurMedical,
    Medecin,
    MedecinDentiste,
    Opticien,
    Orthoptiste,
    Osteopathe,
    Pharmacien,
    Physiotherapeute,
    Podologue,
    PsychotherapeuteNonMedecin,
    SageFemme,
    TechnicienEnAnalysesBiomedicales,
    TechnicienEnRadiologieMedicale,
    TechnicienEnSalleDOperation,
    TherapeuteEnPsychomotricite;
}
