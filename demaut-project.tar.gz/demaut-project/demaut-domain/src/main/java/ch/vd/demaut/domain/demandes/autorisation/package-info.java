/**
 * Module des demandes d'autorisation
 */
package ch.vd.demaut.domain.demandes.autorisation;