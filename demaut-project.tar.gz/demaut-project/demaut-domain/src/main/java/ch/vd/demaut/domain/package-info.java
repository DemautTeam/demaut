/**
 * Ensemble des modules, aggrégats, entities et VO qui représente le domaine Demaut
 */
package ch.vd.demaut.domain;