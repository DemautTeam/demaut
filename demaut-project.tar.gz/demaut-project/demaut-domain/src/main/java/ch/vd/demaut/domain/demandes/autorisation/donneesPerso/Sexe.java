package ch.vd.demaut.domain.demandes.autorisation.donneesPerso;

public enum Sexe {
    Masculin,
    Feminin
}
