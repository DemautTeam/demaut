package ch.vd.demaut.domain.demandes.autorisation.donneesPerso;

import ch.vd.demaut.commons.vo.LocalDateVO;
import org.joda.time.LocalDate;

public class DateDeNaissance extends LocalDateVO {

    // ********************************************************* Fields
    public DateDeNaissance(LocalDate value) {
        super(value);
    }

    // ********************************************************* Business Methods

}
