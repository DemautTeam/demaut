package ch.vd.demaut.services.demandes.autorisation.service.mock;

import ch.vd.demaut.services.demandes.autorisation.DemandeAutorisationService;
import ch.vd.demaut.services.demandes.autorisation.impl.DemandeAutorisationServiceImpl;

public class DemandeAutorisationServiceMock extends DemandeAutorisationServiceImpl implements DemandeAutorisationService {

}
