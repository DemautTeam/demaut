/**
 * Common classes utilisées par les building blocks DDD : Modulkes, Aggregats, Entities, VO, Functional Keys...
 */
package ch.vd.demaut.commons;