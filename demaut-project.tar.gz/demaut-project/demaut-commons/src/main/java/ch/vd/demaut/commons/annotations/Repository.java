package ch.vd.demaut.commons.annotations;

/**
 * Identifies a Repository in the DDD meaning i.e. A repository represents all objects of a certain type and acts as a collection
 *
 * @see
 */
public @interface Repository {

}
