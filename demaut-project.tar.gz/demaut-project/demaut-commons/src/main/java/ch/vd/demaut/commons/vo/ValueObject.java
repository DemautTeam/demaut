package ch.vd.demaut.commons.vo;

/**
 * Identify a Value Object.
 *
 * @see http://en.wikipedia.org/wiki/Value_object#Value_Objects_in_Java
 */
public interface ValueObject {

}
