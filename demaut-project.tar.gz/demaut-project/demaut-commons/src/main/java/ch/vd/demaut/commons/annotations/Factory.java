package ch.vd.demaut.commons.annotations;

/**
 * Identifies a Factory in the DDD context.
 */
public @interface Factory {

}
