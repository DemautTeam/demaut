/**
 * Describes util classes for validation using JavaBean Validation mechanism
 */
package ch.vd.demaut.commons.validation;