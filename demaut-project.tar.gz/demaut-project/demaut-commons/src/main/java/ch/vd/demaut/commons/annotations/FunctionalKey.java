package ch.vd.demaut.commons.annotations;

/**
 * Identifies a Functional Key of an Entity.
 */
public @interface FunctionalKey {

}
