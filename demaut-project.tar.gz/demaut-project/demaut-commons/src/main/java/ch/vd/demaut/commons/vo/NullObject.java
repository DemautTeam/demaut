package ch.vd.demaut.commons.vo;

/**
 * A null object
 * http://en.wikipedia.org/wiki/Null_Object_pattern
 */
public interface NullObject {

}
