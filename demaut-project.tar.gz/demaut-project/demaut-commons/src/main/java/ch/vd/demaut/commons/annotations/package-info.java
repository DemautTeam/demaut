/**
 * Common annotation classes for DDD building blocks : Aggregats, Entities,...
 */
package ch.vd.demaut.commons.annotations;