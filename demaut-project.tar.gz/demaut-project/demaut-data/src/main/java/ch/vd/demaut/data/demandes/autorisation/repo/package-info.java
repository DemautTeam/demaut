/**
 * 
 */
/**
 * @author fabien
 *
 */
package ch.vd.demaut.data.demandes.autorisation.repo;