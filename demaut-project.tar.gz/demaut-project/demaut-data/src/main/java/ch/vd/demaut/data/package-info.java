/**
 * 
 */
package ch.vd.demaut.data;