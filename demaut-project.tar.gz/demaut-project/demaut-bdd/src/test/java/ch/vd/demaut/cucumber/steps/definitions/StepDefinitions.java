package ch.vd.demaut.cucumber.steps.definitions;

public abstract class StepDefinitions {

}
